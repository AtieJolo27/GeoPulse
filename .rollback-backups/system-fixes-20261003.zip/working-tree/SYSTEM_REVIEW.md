# GeoPulse real-world system review

## Remediation status

The findings below describe the original audited implementation. The subsequent fixes add authenticated farm and zone access, explicit device assignments, validated ingestion, stale/incomplete-reading handling, measured nutrient PPM, and model approval gates. Fabricated training features, universal watering prescriptions, invented fertilizer deficits, and generated model explanations have been removed from active flows. Shared helpers now live outside Expo's route directory.

Local verification passed: TypeScript, ESLint, 19 JavaScript tests, 33 backend tests, and web and Android exports. These checks do not validate sensor calibration, agricultural outcomes, deployed database policies, or firmware compatibility. The database migration is prepared but has not been applied. Recommendation models remain withheld until reviewed artifacts and field evidence satisfy the approval policy. See [deployment and field-validation instructions](backend/DEPLOYMENT_AND_VALIDATION.md).

Reviewed 3 October 2026. Scope: checked-in mobile app, FastAPI backend, training and prediction code, datasets, migrations, and local tests. This is a source and dataset audit, not a hardware calibration, field trial, live database policy audit, or production deployment test. No application behavior was changed for this review.

## Verdict

The monitoring and decision-support concept is reasonable. The implementation is a research prototype with useful safeguards, but the repository does not establish that its agricultural decisions are valid in real fields. Current irrigation advice, fertilizer classifications, and nutrient reference gaps should not be treated as validated prescriptions. This conclusion follows from specific data and implementation problems, not an arbitrary numerical rating.

## Findings, ordered by practical impact

### 1. Critical: crop training inputs do not represent measured soil conditions

Evidence: `backend/app/machine_learning/convert_dataset.py:20` converts rainfall to a 20–95% soil-moisture value by linear scaling. All 2,200 checked-in soil dataset rows reproduce that formula. Line 25 creates soil temperature by subtracting a random 0.5–2.5 degrees from air temperature. These are generated features, not field measurements.

Consequence: the crop model learns relationships involving transformed rainfall and invented soil temperature, then receives actual sensor values at inference. Matching feature names does not establish matching physical meaning. Irrigation can also change measured moisture without changing the climate suitability of a crop. Random train/test accuracy on this dataset cannot demonstrate real-field validity.

Needed: retain only features whose measurement definitions match the training data, or collect matched real observations. Evaluate on independent farms, seasons, and soil types; record dataset provenance and units.

### 2. Critical: irrigation uses a universal, unvalidated threshold and mixed-zone readings

Evidence: `app/(drawer)/(tabs)/soil_moisture/soil_moistures.tsx:15` sets 70–75% as the target for every field. Its query at line 48 retrieves the latest sensor readings without a zone filter. Its confidence is a threshold-distance calculation, with an arbitrary 90% inside the band.

Consequence: a reading from one zone can produce advice for another. A calibrated volumetric water content, relative saturation, and raw sensor percentage are different quantities; one universal percentage cannot safely represent all soils and crops. Moving from 69.9% to 70% also changes the displayed confidence from nearly zero to 90% without evidence of greater certainty.

Needed: scope query and cache to farm, zone, and user; validate readings; define sensor measurement basis and calibration; use soil-specific field capacity and crop root-zone context. Replace the confidence label with a description of what is actually calculated. Withhold actionable guidance when data are stale or calibration is unknown.

Reference: [UMN Extension soil-moisture sensor guidance](https://extension.umn.edu/natural-resources/conservation/agricultural-soil-and-water/irrigation/soil-moisture-sensors-for-irrigation-scheduling) explains field capacity, representative locations, and root-zone sensor placement. These principles do not establish Philippine crop-specific numeric thresholds.

### 3. High: fertilizer labels force a product recommendation

Dataset inspection: 2,200 rows; five fertilizer classes; no no-fertilizer class. All 213 rows with Normal/Normal/Normal nutrient statuses recommend balanced 14-14-14. Another 50 rows with High/Normal/Normal recommend that same product. All 532 Low/Normal/Low rows recommend urea, which does not address their labeled potassium shortage. These are dataset labels, not observed fertilizer outcomes.

Consequence: the classifier cannot decide that fertilizer is unnecessary. Its labels do not consistently represent complete nutrient management. Training accuracy can reflect reproduction of those labels without showing yield benefit or suitable application timing. Label patterns appear rule-derived, but their actual authoring method and expert validation are not documented here.

Needed: establish nutrient need independently before ranking products; include no application, insufficient evidence, and unsupported crop outcomes. Validate labels with local agronomists and representative soil tests. Record previous amendments, crop stage, yield target, product composition, and application constraints when calculating a plan.

### 4. High: feature and crop vocabulary mismatches

Evidence: fertilizer training uses the original dataset's `temperature`; conversion explicitly identifies that source column as air temperature. `predict_fertilizer.py:21` supplies soil temperature instead. The training CSV uses `maize`, while the planting picker uses `corn`. Many other selectable crops, including eggplant, tomato, sugarcane, and cassava, are absent from the inspected fertilizer training labels.

Consequence: some predictions use a different physical feature than training; other selected crops cannot be encoded. The zone service catches unsupported crops, which is good, but does not make them supported.

Needed: enforce one feature schema and explicit crop aliases. Display actual supported crops, and offer a clear non-model guidance route for unsupported crops. Stored model artifacts could not be inspected in this environment because `joblib` is absent; training-label findings do not prove the exact deployed artifact contents.

### 5. High: device-to-zone ingestion is incomplete in the checked-in backend

Evidence: `AppContext.tsx` calls GET/POST `/device/active-zone`; neither route exists in `backend/app/main.py`. Switching zones changes local state before the backend call and only logs failures. POST `/sensor` generates random data, omits air temperature/humidity, and supplies no zone. POST `/predict` saves prediction records, not a zone-linked source sensor record.

Consequence: this repository does not demonstrate a complete real-sensor ingestion path. Selecting a field on the phone is not proof that the physical sensor moved there. Deployed firmware or a different backend might implement more, but they were not available for verification.

Needed: identify each device and record its physical assignment; ingest a validated measurement payload with zone, device ID, sample time, and provenance. Separate simulation from live records. Report assignment failures to the user and test the actual ESP32-to-database workflow.

### 6. High: history does not track the selected field's latest measurements

Evidence: `lib/getHistory.ts:18` reads `crop_predictions`, without farm/zone filters, in ascending timestamp order followed by a limit of 30. The chart and history PDF use this helper. The newer zone recommendation endpoint does not persist predictions.

Consequence: history shows the oldest 30 prediction events, potentially from multiple zones, rather than the latest source measurements. Repeated prediction requests can distort history sampling, while new zone-route predictions do not populate this history. Missing chart values are converted with `Number`, which can turn null into zero.

Needed: chart source sensor records for the selected zone; fetch latest records first, then reverse for display. Store prediction history separately with reading, zone, crop context, and model version. Treat unavailable values as missing points.

### 7. High: authentication does not establish backend farm authorization

Evidence: the UI uses Supabase login, but the FastAPI routes have no request authentication or user-to-farm membership check. Farm scope comes from `DEFAULT_FARM_ID`. Zone API fetches do not send a user token. Included migrations do not establish a complete row-level security policy set. The Groq endpoint also lacks visible authentication/rate limiting.

Consequence: client login alone does not restrict these endpoints to authorized farmers. The actual impact depends on network exposure, deployed database policies, and backend key permissions, which were not inspected. Cached sensor/irrigation data are not consistently user-scoped or cleared at logout.

Needed: verify tokens on the server, authorize farm membership, enforce database policies and device identity, and isolate user caches. Verify with cross-account tests rather than assuming frontend login provides protection.

### 8. High: the recently added PPM summary is only reference arithmetic

Evidence: `components/NutrientPpmSummary.tsx` subtracts current N/P/K readings from provisional global minima in `lib/soilHealthScore.ts`: N 20, P 15, K 15. This is not a verified crop requirement. The component explicitly distinguishes gaps from application doses.

Consequence: calling these gaps the needed fertilizer PPM would overstate the evidence. Soil ppm does not directly specify grams of fertilizer or ppm in irrigation water. Soil-test method, nutrient form, soil characteristics, and product composition matter. A disclaimer does not validate the underlying targets.

Needed: use verified crop-specific, measurement-specific targets; otherwise label the comparison as exploratory or withhold a nutrient-need claim. For application planning use an agronomically supported nutrient rate and product conversion, including the N/P2O5/K2O basis.

References: [DA-BSWM FertMap](https://nshp.bswm.da.gov.ph/fertmap/) and [UMN Extension soil-test interpretation](https://extension.umn.edu/agriculture/specialty-crops/interpreting-soil-tests-for-fruit-and-vegetable-crops). Foreign crop thresholds must not be copied into Philippine recommendations without validation.

### 9. Medium: displayed explanations and health indicators exceed their evidence

The sensor index averages six provisional factors, including air temperature and humidity. It is not a comprehensive soil-health assessment, although the code appropriately labels it provisional and flags individual problems. Dashboard sensor cards still say Ideal. The zone model ignores soil type even though zone creation promises soil-type-constrained recommendations. No freshness cutoff protects the zone predictions from old readings.

Groq explanations receive readings and a suggested product/crop, but not the classifier's decision path or retrieved source excerpts. The fertilizer explanation omits the planted crop context. Thus the text is a separate generated assessment, not a verified explanation of the classifier. Fixed reference links do not demonstrate that each generated claim is supported. Daily tips explicitly avoid inventing observations and doses, which is a useful safeguard.

Needed: distinguish measured values, heuristic comparisons, model rankings, and general guidance. Add freshness/calibration gates and ensure claims match implemented filtering. Carry crop context into explanations and ground specific agronomic claims in checked source content. [Scikit-learn calibration documentation](https://scikit-learn.org/stable/modules/calibration.html) explains why probability estimates need calibration before interpreting them as confidence.

### 10. Medium: deployment and operational checks remain unresolved

Type checking reports 11 errors in HeaderActions, SensorWifiScreen, and UrgentCard. Full lint reports 22 errors/33 warnings; one error comes from a generated Expo file and three from test environment configuration, leaving 18 errors in app source. Some are compiler/lint compatibility findings rather than proven runtime failures. UrgentCard's route is also inconsistent with the actual route and omits source-reading parameters.

The Expo Groq handler is a server route, but the project config selects static web output and native API fallback shares the FastAPI base URL; that backend has no `/api/groq` route. A separate deployed Expo server might exist, but its setup is not demonstrated. [Expo API route documentation](https://docs.expo.dev/router/web/api-routes/) requires a deployed server for production. The installed Expo dependency is v57 while AGENTS.md requests reading v54 docs: reconcile intended SDK separately from this review.

Backend requirements omit `supabase` and `python-dotenv` despite direct imports. `test_ml.py` imports a nonexistent `train_model` function and imports a training script with top-level execution. POST `/sensor` reports success even if the save helper catches and suppresses an insertion failure. Wi-Fi provisioning puts the password in an HTTP query string; validate the local provisioning security and native network configuration with the device.

## What is supported by the current evidence

- The dashboard and newer crop/fertilizer route select zone-linked readings instead of guessing a zone for unassigned data.
- The zone service rejects incomplete latest measurements rather than silently using old data, uses the planted crop when available, and retains crop results when fertilizer encoding fails.
- Recommendation scores are labeled rankings rather than success probabilities. Missing/invalid sensor data withhold the overall index.
- Planting-date checks, English/Tagalog support, error states, and some caching improve usability.
- Focused local tests: 17 JavaScript tests and 6 Python zone-service tests passed. These prove their covered behavior, not sensor accuracy or agronomic outcomes.

## Recommended order of work

1. Make all measurements traceable to the correct device, zone, sample time, and measurement definition. Fix mixed-zone irrigation/history and stale-data handling.
2. Suspend unsupported prescription claims and invented confidence values. Calibrate sensors against appropriate reference measurements and soil laboratory methods.
3. Replace or validate fertilizer labels, align model input features/crop vocabulary, and test on independent local farms and seasons.
4. Implement user/farm authorization, reproducible dependency installation, production AI hosting, and clean source checks.
5. Run a supervised local field pilot with an agricultural technician. Measure advice correctness, water use, fertilizer use, costs, and crop outcomes before claiming improvements.

The defensible current description is a prototype for displaying soil measurements and exploring model-ranked options. Validated field recommendations require additional evidence.
