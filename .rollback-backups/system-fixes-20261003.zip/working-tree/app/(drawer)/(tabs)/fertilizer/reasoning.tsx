import RecommendationAssessment from '@/components/RecommendationAssessment';
export default function Reasoning() { return <RecommendationAssessment kind="fertilizer" />; }
