import NutrientHistoryChart from '@/shared/components/HistoryChart';
import SoilHealthChart from '@/shared/components/SoilHealthChart';
import { SectionHeader } from '@/shared/components/ui/SectionHeader';
import { useApp } from '@/shared/lib/AppContext';
import { exportSoilHistoryPDF } from '@/shared/lib/exportSoilPDF';
import { useThemeColors } from '@/shared/lib/useThemeColors';
import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { Alert, ScrollView, Text, TouchableOpacity, View } from 'react-native';

type ChartMode = 'health' | 'soil';

export default function History() {
  const { t, activeZoneId, user, zones } = useApp();
  const colors = useThemeColors();
  const [exporting, setExporting] = useState(false);
  const [mode, setMode] = useState<ChartMode>('health');

  const handleExportPDF = async () => {
    if (activeZoneId === null) return;
    try { setExporting(true); await exportSoilHistoryPDF(activeZoneId); }
    catch { Alert.alert(t('Export failed', 'Hindi na-export'), t('Unable to generate the soil report.', 'Hindi magawa ang soil report.')); }
    finally { setExporting(false); }
  };

  return (
    <ScrollView className="flex-1 px-5 pt-5" style={{ backgroundColor: colors.bg }} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 105 }}>
      <Text style={{ color: colors.subText }}>{zones.find(zone => zone.id === activeZoneId)?.name_en ?? t('Select a zone', 'Pumili ng sona')}</Text>
      <Text className="mt-1" style={{ fontSize: 25, fontWeight: '800', color: colors.text }}>{t('Recorded measurements', 'Mga naitalang sukat')}</Text>
      <Text className="mt-2" style={{ fontSize: 13, lineHeight: 19, color: colors.subText }}>{t('Review one trend at a time to spot changes clearly.', 'Suriin ang isang trend sa bawat pagkakataon para madaling makita ang pagbabago.')}</Text>

      <View className="mt-6 flex-row rounded-2xl p-1" style={{ backgroundColor: colors.cardBgAlt }}>
        {([['health', t('Sensor index', 'Sensor index')], ['soil', t('Nutrients & soil', 'Nutrients at lupa')]] as const).map(([key, label]) => (
          <TouchableOpacity key={key} onPress={() => setMode(key)} className="flex-1 rounded-xl px-3 py-3" style={{ backgroundColor: mode === key ? colors.cardBg : 'transparent' }}>
            <Text numberOfLines={1} className="text-center text-xs font-bold" style={{ color: mode === key ? colors.primaryDark : colors.subText }}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View className="mt-6 rounded-3xl border py-2" style={{ backgroundColor: colors.cardBg, borderColor: colors.cardBorder }}>
        <View className="px-3 pt-2"><SectionHeader title={mode === 'health' ? t('Sensor index trend', 'Trend ng sensor index') : t('Soil data trend', 'Trend ng soil data')} subtitle={t('Tap a point to see its reading.', 'I-tap ang point para makita ang reading.')} /></View>
        {activeZoneId === null ? <Text style={{ color: colors.subText, padding: 16 }}>{t('Select a zone on the dashboard.', 'Pumili ng sona sa dashboard.')}</Text> : mode === 'health' ? <SoilHealthChart key={`${user?.id}:${activeZoneId}`} zoneId={activeZoneId} /> : <NutrientHistoryChart key={`${user?.id}:${activeZoneId}`} zoneId={activeZoneId} />}
      </View>

      <TouchableOpacity onPress={handleExportPDF} disabled={exporting || activeZoneId === null} className="mt-6 flex-row items-center justify-center rounded-2xl border px-4 py-4" style={{ borderColor: colors.border, backgroundColor: colors.cardBg, opacity: exporting ? 0.6 : 1 }}>
        <Ionicons name="document-text-outline" size={19} color={colors.primaryDark} />
        <Text className="ml-2 font-bold" style={{ color: colors.primaryDark }}>{exporting ? t('Preparing report...', 'Inihahanda ang report...') : t('Export PDF report', 'I-export ang PDF report')}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
