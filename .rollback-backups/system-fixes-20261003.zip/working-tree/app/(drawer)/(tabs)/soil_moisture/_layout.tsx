import { HeaderActions } from '@/shared/components/HeaderActions';
import { Stack } from 'expo-router';


export default function IrrigationLayout() {
    return (
        <Stack
        screenOptions={{
            headerTitle:"Soil Moisture",
      headerTitleStyle: { fontWeight: 'bold', fontSize: 20, color: '#F0FDF4' },
      headerStyle: { backgroundColor: '#1B5E37' },
      headerTintColor: '#F0FDF4',
      headerRight: () => <HeaderActions />
        }}>
            <Stack.Screen
            name='soil_moistures'
            />
        </Stack>
    );
}
