import { useApp } from '@/shared/lib/AppContext';
import { useThemeColors } from '@/shared/lib/useThemeColors';
import { readingIsFresh, validMoisture } from '@/lib/readingQuality';
import { supabase } from '@/lib/supabaseClient';
import { useEffect, useState } from 'react';
import { ActivityIndicator, RefreshControl, ScrollView, Text, View } from 'react-native';
type Reading = { id: number; soil_moisture: number | string | null; created_at: string };
export default function Irrigation() {
  const { activeZoneId, user, t } = useApp();
  const colors = useThemeColors();
  if (activeZoneId === null) return <Text style={{ color: colors.text, padding: 24 }}>{t('Select a zone on the dashboard.', 'Pumili ng sona sa dashboard.')}</Text>;
  return <ZoneMoisture key={`${user?.id}:${activeZoneId}`} zoneId={activeZoneId} />;
}
function ZoneMoisture({ zoneId }: { zoneId: number }) {
  const { t, fontScale } = useApp();
  const colors = useThemeColors();
  const [readings, setReadings] = useState<Reading[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    const timer = setInterval(() => setNow(Date.now()), 60_000);
    const load = async () => {
      try {
        const { data, error: failed } = await supabase.from('sensor_readings')
          .select('id, soil_moisture, created_at').eq('zone_id', zoneId)
          .order('created_at', { ascending: false }).order('id', { ascending: false })
          .limit(10).abortSignal(controller.signal);
        if (failed) throw failed;
        if (active) { setReadings(data ?? []); setError(false); }
      } catch { if (active) setError(true); }
      finally { if (active) setLoading(false); }
    };
    void load();
    const channel = supabase.channel(`moisture-${zoneId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'sensor_readings', filter: `zone_id=eq.${zoneId}` }, () => { void load(); }).subscribe();
    return () => { active = false; controller.abort(); clearInterval(timer); void supabase.removeChannel(channel); };
  }, [zoneId, attempt]);
  const latest = readings[0];
  const moisture = validMoisture(latest?.soil_moisture);
  const fresh = readingIsFresh(latest?.created_at, now);
  return <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={{ padding: 24, paddingBottom: 110 }}
    refreshControl={<RefreshControl refreshing={loading} onRefresh={() => { setLoading(true); setAttempt(value => value + 1); }} />}>
    <Text style={{ color: colors.text, fontSize: 24 * fontScale, fontWeight: '700' }}>{t('Soil moisture measurements', 'Mga sukat ng halumigmig ng lupa')}</Text>
    {loading && <ActivityIndicator color={colors.primary} />}
    {error && <Text accessibilityRole="alert" style={{ color: colors.warning, marginTop: 16 }}>{t('Refresh failed. Displayed measurements may be out of date.', 'Hindi na-refresh. Maaaring luma ang ipinapakitang sukat.')}</Text>}
    <View style={{ backgroundColor: colors.cardBg, borderRadius: 16, padding: 20, marginTop: 20 }}>
      <Text style={{ color: colors.text, fontSize: 38 * fontScale }}>{moisture === null ? '--' : `${moisture.toFixed(1)}%`}</Text>
      <Text style={{ color: colors.subText }}>{latest ? new Date(latest.created_at).toLocaleString() : t('No measurements available', 'Walang sukat')}</Text>
      <Text style={{ color: colors.subText, marginTop: 12 }}>{!fresh ? t('A fresh measurement is needed.', 'Kailangan ng bagong sukat.') : t('Recent sensor measurement', 'Kamakailangang sukat ng sensor')}</Text>
      <Text style={{ color: colors.subText, marginTop: 12, lineHeight: 21 * fontScale }}>{t('Watering need cannot be determined from an uncalibrated percentage. Check the root-zone soil and crop condition. Have your agricultural technician set guidance for this soil, crop and sensor.', 'Hindi matutukoy ang pangangailangan sa tubig mula sa porsiyentong walang calibration. Suriin ang lupa sa mga ugat at kondisyon ng pananim. Magpatakda ng gabay sa agricultural technician para sa lupa, pananim at sensor.')}</Text>
    </View>
    <Text style={{ color: colors.text, fontSize: 18 * fontScale, fontWeight: '700', marginVertical: 20 }}>{t('Recent readings in this zone', 'Kamakailangang sukat sa sonang ito')}</Text>
    {readings.slice(1).map(row => <View key={row.id} style={{ padding: 14, marginBottom: 8, backgroundColor: colors.cardBg, borderRadius: 12 }}>
      <Text style={{ color: colors.text }}>{validMoisture(row.soil_moisture)?.toFixed(1) ?? '--'}% ? {new Date(row.created_at).toLocaleString()}</Text>
    </View>)}
  </ScrollView>;
}
