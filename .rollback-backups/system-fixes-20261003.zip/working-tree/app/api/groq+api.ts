// Web server deployments may proxy to FastAPI. Native clients use FastAPI directly.
export async function POST(request: Request) {
  const authorization = request.headers.get('Authorization');
  if (!authorization?.startsWith('Bearer ')) return Response.json({ error: 'Sign in required' }, { status: 401 });
  const base = process.env.EXPO_PUBLIC_API_URL;
  if (!base) return Response.json({ error: 'Backend URL is not configured' }, { status: 503 });
  try {
    const response = await fetch(`${base.replace(/\/+$/, '')}/api/groq`, {
      method: 'POST', headers: { Authorization: authorization, 'Content-Type': 'application/json' },
      body: await request.text(), signal: AbortSignal.timeout(35000),
    });
    return new Response(await response.text(), { status: response.status, headers: { 'Content-Type': 'application/json' } });
  } catch { return Response.json({ error: 'Guidance service unavailable' }, { status: 503 }); }
}
