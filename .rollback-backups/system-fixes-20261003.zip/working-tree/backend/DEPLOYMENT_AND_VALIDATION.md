# Deploying the system fixes

The app now displays traceable measurements and general care guidance. Automatic watering decisions, nutrient deficits, and model rankings are withheld until the required evidence exists. This is deliberate: the original synthetic crop features and fertilizer labels are not field validation.

## Release order

1. Review and apply the Supabase migrations in order, including `202610030001_measurement_access.sql`. Test on a staging copy first. This migration changes read/write grants and creates restrictive membership policies; existing users need explicit membership. Unassigned legacy readings remain unassigned and are marked unverified. No data are guessed or backfilled into a zone. The SQL has not been applied to a live database by this task.
2. As a database administrator, insert the correct pairs into `farm_memberships(farm_id, user_id)`. Get user UUIDs from Supabase Auth and farm IDs from the actual farms table. Do not infer membership from user-editable metadata.
3. Install `requirements.lock.txt` in the backend environment. Set `SUPABASE_URL`, a **server-only service role** `SUPABASE_KEY`, `DEFAULT_FARM_ID`, and a comma-separated `ALLOWED_ORIGINS` list of web origins. Native clients do not need a browser CORS origin. Enable `GROQ_API_KEY` only on the backend if general crop-care guidance is wanted. Run `uvicorn app.main:app` from the backend directory. Never expose the service key in an `EXPO_PUBLIC_` variable.
4. Deploy the updated backend before updating clients. `/predict` and global prediction history are intentionally retired. Set `EXPO_PUBLIC_API_URL` in the app to the deployed FastAPI URL. Native care requests and web requests use `/api/groq` on that backend; an optional Expo server route proxies authenticated web requests. Web server output is enabled. Expo v57 remains the installed SDK; no implicit downgrade to v54 was performed.
5. Verify two separate user accounts: an unauthenticated request returns 401; a valid non-member returns 403; a member cannot retrieve another farm's zone. Direct database requests with the publishable key must also be blocked by RLS. Confirm the migration grants and any additional existing policies against the real schema.

## Real sensor integration

Register each sensor from the Sensor settings **Field assignment** tab. Save its device UUID and one-time token on that physical device. Place the device in the field, then explicitly assign it to the selected zone. Selecting a zone on the dashboard only changes the user's viewing preference.

Firmware must send HTTPS POST `/sensor` with header `X-Device-Token` and this JSON shape:

```json
{
  "device_id": "device-uuid",
  "zone_id": 1,
  "sample_id": "new-uuid-for-each-physical-sample",
  "sampled_at": "2026-10-03T00:00:00Z",
  "soil_moisture": 35.5,
  "soil_temperature": 24,
  "air_temperature": 27,
  "humidity": 70,
  "ph": 6.4,
  "nitrogen": 12.5,
  "phosphorus": 19,
  "potassium": 21
}
```

Example values are protocol examples, not agronomic targets. Send the sensor's actual measurement values and correctly synchronized sample time. Air temperature and humidity are optional: a soil-only probe must omit them unless separate hardware measures them. Do not substitute soil temperature for air temperature or invent humidity. Models that require these inputs remain unavailable when they are missing. Retries reuse the same sample UUID. The database checks credential and assignment under a lock and prevents duplicate samples. It never assumes that viewing a different zone means a sensor moved. Offline queued samples from a previous assignment must be reviewed rather than relabeled into a new zone.

Use a protected physical provisioning AP. The app now requires POST `/connect` with JSON `ssid` and `password`; there is no query-string credential fallback. The firmware must implement this contract. Device firmware and native platform cleartext-network configuration were not present for verification. Test the real phone and ESP32 before release. Keep HTTP access confined to the trusted local provisioning network; cloud ingestion uses HTTPS.

If a device credential is lost, register a replacement device and disable the old device as an administrator. Never show stored token hashes in the client. Implement a controlled credential rotation procedure before a larger deployment.

## Calibration and agricultural approval

Record a documented calibration in `sensor_calibrations`, tied to the actual device. Include its measurement protocol, a validation report, the reviewer UUID, and expiry. The reviewer must verify nutrient form/units and comparison to appropriate laboratory methods; a nonempty document name alone is not scientific validation. An administrator may then set that device's `calibration_id`. The ingestion RPC copies only a currently valid calibration belonging to that device. Missing calibration still permits measurement display but withholds crop/fertilizer models. Recalibrate when replacing the sensor or changing its measurement protocol.

The one-hour freshness limit is an operational safeguard. It is not an irrigation threshold. Moisture percentages have no universal target. Establish field capacity, measurement basis, representative depth/placement, root-zone water status, and crop-specific rules with an agricultural technician before implementing watering advice.

The PPM panel displays reported soil measurements. It does not calculate crop nutrient need or a fertilizer mixture. Future prescriptions require an appropriate soil test, crop and stage, yield target, previous inputs, product composition, and the distinction between elemental P/K and fertilizer P2O5/K2O.

## Rebuilding models

Legacy CSVs and pickle artifacts remain as historical research material. They are not approved field models. Training no longer runs on import, and conversion no longer fabricates moisture or soil temperature.

New training requires reviewed observations with `farm_id`, `season`, `measurement_protocol`, `label_reviewed`, and actual features/labels. Crop features are nitrogen, phosphorus, potassium, air temperature, humidity, and pH. Fertilizer temperature is consistently air temperature; corn is normalized to maize. Fertilizer data must contain expert-reviewed **No application** outcomes and complete nutrient-management labels.

```powershell
python -m app.machine_learning.train_model reviewed_crop_fields.csv --output-dir reviewed-models
python -m app.machine_learning.train_fertilizer_model reviewed_fertilizer_fields.csv --output-dir reviewed-models
```

Run these from the backend directory. Training holds out entire farms and writes an evaluation report plus metadata with `approved_for_field_use: false`. Accuracy alone does not authorize deployment. An independent local evaluation must assess season/soil transfer, per-crop errors, fertilizer/no-application errors, calibration, and field outcomes. After review, metadata must identify the validation report, exact feature schema, measurement protocol, model version, and artifact SHA-256. The runtime checks these before loading an artifact. Keep reviewed encoders together with their model. These checks ensure review traceability; they do not replace the review.

## Local checks

```powershell
npx.cmd tsc --noEmit
npx.cmd eslint . --max-warnings 0
node --test tests/*.test.cjs
npx.cmd expo export --platform web
```

From the backend directory:

```powershell
../.venv/Scripts/python.exe -B -m unittest tests.test_zone_recommendations tests.test_ml tests.test_api_contract
```

Tests use fake databases and do not contact Supabase. Old test scripts that queried live databases or inserted simulated readings on import have been removed. A real staging-database/firmware integration test and supervised agricultural field pilot remain required. For multiple backend replicas, add a distributed rate limiter; the included per-user limiter protects one process only.
