"""Retired MySQL adapter. Production measurements use authenticated Supabase ingestion."""

def get_connection():
    raise RuntimeError('Legacy MySQL storage is retired; use the zone-scoped Supabase API.')

