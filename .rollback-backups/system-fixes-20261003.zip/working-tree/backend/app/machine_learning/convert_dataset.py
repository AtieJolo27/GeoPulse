"""Export legacy observations without fabricating sensor measurements.
Output is exploratory only: provenance and laboratory measurement basis remain unverified.
"""
import argparse
import csv
from pathlib import Path
from app.services.model_policy import CROP_FEATURES

def convert_dataset(source, destination):
    mapping = {'nitrogen': 'N', 'phosphorus': 'P', 'potassium': 'K',
               'air_temperature': 'temperature', 'humidity': 'humidity', 'ph': 'ph', 'crop': 'label'}
    with Path(source).open(newline='') as input_file, Path(destination).open('w', newline='') as output_file:
        writer = csv.DictWriter(output_file, fieldnames=CROP_FEATURES + ['crop'])
        writer.writeheader()
        for row in csv.DictReader(input_file):
            writer.writerow({key: row[value] for key, value in mapping.items()})

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source')
    parser.add_argument('destination', help='Exploratory output; not an approved training dataset')
    args = parser.parse_args()
    convert_dataset(args.source, args.destination)
