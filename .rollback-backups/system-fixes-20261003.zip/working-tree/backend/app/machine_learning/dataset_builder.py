"""The unscoped legacy training extractor is intentionally retired."""

def fetch_all_sensor_data():
    raise RuntimeError('Training requires an explicit reviewed field CSV with farm and season provenance.')
