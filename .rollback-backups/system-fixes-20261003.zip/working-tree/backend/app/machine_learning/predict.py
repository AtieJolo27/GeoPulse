from app.services.model_policy import MODEL_DIR, CROP_FEATURES, approved_metadata

def predict_crop(sensor_data):
    metadata = approved_metadata('crop', CROP_FEATURES)
    import joblib
    import pandas as pd
    model = joblib.load(MODEL_DIR / 'crop_model.pkl')
    if list(getattr(model, 'feature_names_in_', [])) != CROP_FEATURES:
        raise ValueError('Crop model feature schema is incompatible; retraining required.')
    features = pd.DataFrame([{key: sensor_data[key] for key in CROP_FEATURES}])
    rows = [{'crop': str(label), 'confidence': round(float(score) * 100, 2)}
            for label, score in zip(model.classes_, model.predict_proba(features)[0])]
    rows.sort(key=lambda row: row['confidence'], reverse=True)
    return {'best_crop': rows[0]['crop'], 'recommendations': rows[:5], 'model_version': metadata['model_version']}
