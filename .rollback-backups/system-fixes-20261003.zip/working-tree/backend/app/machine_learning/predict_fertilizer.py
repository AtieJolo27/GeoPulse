from app.services.model_policy import MODEL_DIR, FERTILIZER_FEATURES, approved_metadata, normalize_crop

def predict_fertilizer(sensor_data, crop_name):
    metadata = approved_metadata('fertilizer', FERTILIZER_FEATURES)
    import joblib
    import pandas as pd
    model = joblib.load(MODEL_DIR / 'fertilizer_model.pkl')
    crop_encoder = joblib.load(MODEL_DIR / 'crop_encoder.pkl')
    fertilizer_encoder = joblib.load(MODEL_DIR / 'fertilizer_encoder.pkl')
    crop_encoded = crop_encoder.transform([normalize_crop(crop_name)])[0]
    if list(getattr(model, 'feature_names_in_', [])) != FERTILIZER_FEATURES or 'No application' not in fertilizer_encoder.classes_:
        raise ValueError('Fertilizer model schema or outcomes are incompatible.')
    features = pd.DataFrame([{'N': sensor_data['nitrogen'], 'P': sensor_data['phosphorus'],
        'K': sensor_data['potassium'], 'temperature': sensor_data['air_temperature'],
        'humidity': sensor_data['humidity'], 'ph': sensor_data['ph'], 'label': crop_encoded}])
    rows = [{'fertilizer': str(fertilizer_encoder.inverse_transform([label])[0]), 'confidence': round(float(score) * 100, 2)}
            for label, score in zip(model.classes_, model.predict_proba(features)[0])]
    rows.sort(key=lambda row: row['confidence'], reverse=True)
    return {'best_fertilizer': rows[0]['fertilizer'], 'recommendations': rows[:5], 'model_version': metadata['model_version']}
