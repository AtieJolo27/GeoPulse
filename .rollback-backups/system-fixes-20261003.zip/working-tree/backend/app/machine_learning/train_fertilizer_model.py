"""Fertilizer labels must include expert-verified no-application outcomes."""
from pathlib import Path
from app.services.model_policy import FERTILIZER_FEATURES
from app.machine_learning.training import train_field_model

def train_fertilizer_model(data, output_dir):
    return train_field_model(data, 'fertilizer', FERTILIZER_FEATURES, 'fertilizer', Path(output_dir))

if __name__ == '__main__':
    import argparse
    import pandas as pd
    parser = argparse.ArgumentParser()
    parser.add_argument('field_csv')
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()
    train_fertilizer_model(pd.read_csv(args.field_csv), args.output_dir)
