"""Train only from explicitly supplied field-labelled observations; never on import."""
from pathlib import Path
from app.services.model_policy import CROP_FEATURES
from app.machine_learning.training import train_field_model

def train_model(data, output_dir):
    return train_field_model(data, 'crop', CROP_FEATURES, 'crop', Path(output_dir))

if __name__ == '__main__':
    import argparse
    import pandas as pd
    parser = argparse.ArgumentParser()
    parser.add_argument('field_csv', help='Reviewed field observations with farm_id and crop label')
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()
    train_model(pd.read_csv(args.field_csv), args.output_dir)
