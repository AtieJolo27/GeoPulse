import hashlib
import json
from app.services.model_policy import normalize_crop

def train_field_model(data, kind, features, target, output_dir):
    import joblib
    import pandas as pd
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import GroupShuffleSplit
    from sklearn.metrics import classification_report
    from sklearn.preprocessing import LabelEncoder
    data = pd.DataFrame(data).copy()
    required = set(features + [target, 'farm_id', 'season', 'measurement_protocol', 'label_reviewed'])
    if not required.issubset(data.columns):
        raise ValueError('Use reviewed field observations with farm, season, measurement protocol and labels; synthetic legacy data are not accepted.')
    if data[list(required)].isna().any().any():
        raise ValueError('Incomplete training observations')
    if not data['label_reviewed'].map(lambda value: value is True or str(value).lower() == 'true').all():
        raise ValueError('Every training label must be reviewed.')
    if data['farm_id'].nunique() < 2 or data['measurement_protocol'].nunique() != 1:
        raise ValueError('At least two independent farms and one consistent measurement protocol are required.')
    version = hashlib.sha256(data.to_csv(index=False).encode()).hexdigest()[:16]
    if kind == 'fertilizer':
        if 'No application' not in set(data[target]):
            raise ValueError('Reviewed no-application examples are required.')
        crop_encoder = LabelEncoder()
        fertilizer_encoder = LabelEncoder()
        data['label'] = crop_encoder.fit_transform(data['label'].map(normalize_crop))
        data[target] = fertilizer_encoder.fit_transform(data[target])
    split = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=42)
    train, test = next(split.split(data, data[target], groups=data['farm_id']))
    if not set(data.iloc[test][target]).issubset(set(data.iloc[train][target])):
        raise ValueError('Holdout contains unseen labels; collect additional independent farm observations.')
    X = data[features].apply(pd.to_numeric, errors='raise')
    import numpy as np
    if not np.isfinite(X.to_numpy()).all():
        raise ValueError('Non-finite training measurements')
    for feature in features:
        if feature in ('nitrogen', 'phosphorus', 'potassium', 'N', 'P', 'K') and (X[feature] < 0).any():
            raise ValueError('Negative nutrient measurements')
        if feature == 'humidity' and not X[feature].between(0, 100).all():
            raise ValueError('Invalid humidity')
        if feature == 'ph' and not X[feature].between(0, 14).all():
            raise ValueError('Invalid pH')
    model = RandomForestClassifier(n_estimators=200, random_state=42, class_weight='balanced')
    model.fit(X.iloc[train], data.iloc[train][target])
    report = classification_report(data.iloc[test][target], model.predict(X.iloc[test]), output_dict=True, zero_division=0)
    output_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, output_dir / f'{kind}_model.pkl')
    if kind == 'fertilizer':
        joblib.dump(crop_encoder, output_dir / 'crop_encoder.pkl')
        joblib.dump(fertilizer_encoder, output_dir / 'fertilizer_encoder.pkl')
    (output_dir / f'{kind}_evaluation.json').write_text(json.dumps({
        'split': 'independent farm holdout', 'train_farms': sorted(map(str, data.iloc[train]['farm_id'].unique())),
        'test_farms': sorted(map(str, data.iloc[test]['farm_id'].unique())), 'report': report,
    }, indent=2))
    # Training does not authorize field deployment; independent review is a separate step.
    (output_dir / f'{kind}_metadata.json').write_text(json.dumps({
        'approved_for_field_use': False, 'features': features, 'model_version': version,
        'measurement_protocol': str(data['measurement_protocol'].iloc[0]), 'validation_report': '',
        'has_no_application_outcome': kind == 'fertilizer',
        'artifact_sha256': hashlib.sha256((output_dir / f'{kind}_model.pkl').read_bytes()).hexdigest(),
    }, indent=2))
    return model
