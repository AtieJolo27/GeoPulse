import hashlib
import os
import secrets
from datetime import datetime, timezone, timedelta
from uuid import UUID
from fastapi import FastAPI, Depends, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.database.supabase import supabase
from app.services.auth import require_farm
from app.services.zone_recommendations import recommend_for_zone
from app.machine_learning.predict import predict_crop
from app.machine_learning.predict_fertilizer import predict_fertilizer
from app.services.ai_guidance import guidance

app = FastAPI()
app.add_middleware(CORSMiddleware,
    allow_origins=[value.strip() for value in os.getenv('ALLOWED_ORIGINS', '').split(',') if value.strip()],
    allow_credentials=False, allow_methods=['GET', 'POST', 'PUT'], allow_headers=['Authorization', 'Content-Type'])

class StrictInput(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False, str_strip_whitespace=True)

class ZoneInput(StrictInput):
    name_en: str = Field(min_length=1, max_length=100)
    name_tl: str = Field(min_length=1, max_length=100)
    soil_type: str = Field(min_length=1, max_length=80)

class ZoneSelection(StrictInput):
    zone_id: int = Field(gt=0, strict=True)

class DeviceInput(StrictInput):
    name: str = Field(min_length=1, max_length=100)

class SensorInput(StrictInput):
    device_id: UUID
    zone_id: int = Field(gt=0, strict=True)
    sample_id: UUID
    sampled_at: datetime
    soil_moisture: float = Field(ge=0, le=100)
    soil_temperature: float = Field(ge=-50, le=80)
    air_temperature: float | None = Field(default=None, ge=-50, le=80)
    humidity: float | None = Field(default=None, ge=0, le=100)
    ph: float = Field(ge=0, le=14)
    nitrogen: float = Field(ge=0)
    phosphorus: float = Field(ge=0)
    potassium: float = Field(ge=0)

    @field_validator('soil_moisture', 'soil_temperature', 'air_temperature', 'humidity', 'ph', 'nitrogen', 'phosphorus', 'potassium', 'zone_id', mode='before')
    @classmethod
    def reject_boolean(cls, value):
        if isinstance(value, bool):
            raise ValueError('Boolean measurements are invalid')
        return value

    @field_validator('sampled_at')
    @classmethod
    def sample_time(cls, value):
        if value.tzinfo is None or value > datetime.now(timezone.utc) + timedelta(minutes=1):
            raise ValueError('Sample time must include timezone and cannot be in the future')
        return value

def checked_zone(zone_id, farm):
    rows = supabase.table('zones').select('*').eq('id', zone_id).eq('farm_id', farm['farm_id']).limit(1).execute().data
    if not rows:
        raise HTTPException(404, 'Zone not found in your farm')
    return rows[0]

@app.get('/')
def home():
    return {'message': 'GeoPulse API is running'}

@app.get('/zones')
def get_zones(farm=Depends(require_farm)):
    rows = supabase.table('zones').select('*').eq('farm_id', farm['farm_id']).order('id').execute().data
    return {'status': 'success', 'data': rows}

@app.post('/zones', status_code=201)
def create_zone(zone: ZoneInput, farm=Depends(require_farm)):
    values = {key: value.strip() for key, value in zone.model_dump().items()}
    if not all(values.values()):
        raise HTTPException(422, 'Zone name and soil type are required')
    values.update(farm_id=farm['farm_id'], name=values['name_en'],
                  boundary_geojson={'type': 'FeatureCollection', 'features': []})
    rows = supabase.table('zones').insert(values).execute().data
    if not rows:
        raise HTTPException(503, 'Zone was not saved')
    return {'status': 'success', 'zone': rows[0]}

# A per-user viewing preference; never changes a physical device assignment.
@app.get('/device/active-zone')
def get_active_zone(farm=Depends(require_farm)):
    rows = supabase.table('farm_user_preferences').select('zone_id').eq('user_id', farm['user_id']).eq('farm_id', farm['farm_id']).limit(1).execute().data
    return {'zone': checked_zone(rows[0]['zone_id'], farm) if rows and rows[0]['zone_id'] else None}

@app.post('/device/active-zone')
def set_active_zone(selection: ZoneSelection, farm=Depends(require_farm)):
    zone = checked_zone(selection.zone_id, farm)
    supabase.table('farm_user_preferences').upsert({**farm, 'zone_id': selection.zone_id}, on_conflict='farm_id,user_id').execute()
    return {'zone': zone, 'device_assignment_changed': False}

@app.post('/devices', status_code=201)
def register_device(device: DeviceInput, farm=Depends(require_farm)):
    token = secrets.token_urlsafe(32)
    rows = supabase.table('sensor_devices').insert({'farm_id': farm['farm_id'],
        'name': device.name.strip(), 'token_hash': hashlib.sha256(token.encode()).hexdigest()}).execute().data
    if not rows:
        raise HTTPException(503, 'Device not saved')
    return {'device_id': rows[0]['id'], 'device_token': token}

@app.get('/devices')
def list_devices(farm=Depends(require_farm)):
    return {'data': supabase.table('sensor_devices').select('id,name,zone_id,enabled,calibration_id').eq('farm_id', farm['farm_id']).execute().data}

@app.put('/devices/{device_id}/zone')
def assign_device(device_id: UUID, selection: ZoneSelection, farm=Depends(require_farm)):
    checked_zone(selection.zone_id, farm)
    rows = supabase.table('sensor_devices').update({'zone_id': selection.zone_id}).eq('id', str(device_id)).eq('farm_id', farm['farm_id']).execute().data
    if not rows:
        raise HTTPException(404, 'Device not found in your farm')
    return {'device_id': str(device_id), 'zone_id': selection.zone_id}

@app.post('/sensor', status_code=201)
def ingest_sensor(sensor: SensorInput, x_device_token: str = Header(default='')):
    if not x_device_token or len(x_device_token) > 256:
        raise HTTPException(401, 'Device credential required')
    # The RPC locks the device assignment, verifies token and inserts atomically.
    payload = sensor.model_dump(mode='json')
    try:
        rows = supabase.rpc('ingest_device_reading', {
            'payload': payload, 'credential_hash': hashlib.sha256(x_device_token.encode()).hexdigest(),
        }).execute().data
    except Exception as exc:
        raise HTTPException(422, 'Measurement rejected. Check device credentials, zone assignment and sample ID.') from exc
    if not rows:
        raise HTTPException(503, 'Measurement was not saved')
    return {'status': 'success', 'reading': rows}

@app.get('/sensor')
def get_sensors(zone_id: int, farm=Depends(require_farm)):
    checked_zone(zone_id, farm)
    rows = supabase.table('sensor_readings').select('*').eq('zone_id', zone_id).order('created_at', desc=True).order('id', desc=True).limit(100).execute().data
    return {'data': rows}

@app.get('/zones/{zone_id}/recommendations')
def zone_recommendations(zone_id: int, farm=Depends(require_farm)):
    checked_zone(zone_id, farm)
    try:
        return recommend_for_zone(supabase, zone_id, farm['farm_id'], predict_crop, predict_fertilizer)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc

@app.post('/predict')
def legacy_prediction(farm=Depends(require_farm)):
    raise HTTPException(410, 'Use the zone recommendation endpoint with traceable source readings.')

@app.get('/predictions')
def legacy_history(farm=Depends(require_farm)):
    raise HTTPException(410, 'Use zone-scoped sensor measurements for history.')

@app.post('/api/groq')
async def crop_guidance(body: dict, farm=Depends(require_farm)):
    return await guidance(body, farm, supabase)
