import os
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from app.database.supabase import supabase

bearer = HTTPBearer(auto_error=False)

def require_user(credentials: HTTPAuthorizationCredentials = Depends(bearer)):
    if credentials is None or credentials.scheme.lower() != 'bearer':
        raise HTTPException(401, 'Sign in required')
    try:
        user = supabase.auth.get_user(credentials.credentials).user
    except Exception as exc:
        raise HTTPException(401, 'Invalid or expired session') from exc
    if user is None:
        raise HTTPException(401, 'Invalid session')
    return user

def require_farm(user=Depends(require_user)):
    try:
        farm_id = int(os.environ['DEFAULT_FARM_ID'])
    except (KeyError, ValueError) as exc:
        raise HTTPException(503, 'Farm configuration unavailable') from exc
    memberships = supabase.table('farm_memberships').select('farm_id').eq('farm_id', farm_id).eq('user_id', str(user.id)).limit(1).execute().data
    if not memberships:
        raise HTTPException(403, 'You are not a member of this farm')
    return {'farm_id': farm_id, 'user_id': str(user.id)}
