import json
from pathlib import Path
import hashlib

MODEL_DIR = Path(__file__).resolve().parents[1] / 'machine_learning' / 'models'
CROP_FEATURES = ['nitrogen', 'phosphorus', 'potassium', 'air_temperature', 'humidity', 'ph']
FERTILIZER_FEATURES = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'label']
CROP_ALIASES = {'corn': 'maize', 'sweet potato': 'sweet_potato'}

def normalize_crop(value):
    value = value.strip().lower()
    return CROP_ALIASES.get(value, value)

def approved_metadata(kind, features):
    try:
        metadata = json.loads((MODEL_DIR / f'{kind}_metadata.json').read_text())
    except (OSError, ValueError):
        raise ValueError('Model unavailable pending independent local validation.')
    if (metadata.get('approved_for_field_use') is not True
            or metadata.get('features') != features
            or not metadata.get('validation_report')
            or not metadata.get('measurement_protocol')
            or not metadata.get('model_version')):
        raise ValueError('Model unavailable pending independent local validation.')
    model_path = MODEL_DIR / f'{kind}_model.pkl'
    if not model_path.exists() or metadata.get('artifact_sha256') != hashlib.sha256(model_path.read_bytes()).hexdigest():
        raise ValueError('Model artifact does not match its reviewed metadata.')
    if kind == 'fertilizer' and metadata.get('has_no_application_outcome') is not True:
        raise ValueError('Fertilizer model must support no application.')
    return metadata
