from app.database.supabase import supabase

def save_sensor_data(sensor_data):
    response = supabase.table('sensor_readings').insert(sensor_data).execute()
    if not response.data:
        raise RuntimeError('Sensor measurement was not saved')
    return response
