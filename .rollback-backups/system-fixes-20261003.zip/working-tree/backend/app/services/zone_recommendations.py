import math
from datetime import datetime, timezone, timedelta
from app.services.model_policy import normalize_crop

FIELDS = ('soil_moisture', 'soil_temperature', 'air_temperature', 'humidity', 'ph', 'nitrogen', 'phosphorus', 'potassium')
MAX_READING_AGE = timedelta(hours=1)

def recommend_for_zone(database, zone_id, farm_id, crop_model, fertilizer_model, now=None):
    zones = database.table('zones').select('*').eq('id', zone_id).eq('farm_id', farm_id).limit(1).execute().data
    if not zones:
        raise ValueError('Zone not found')
    readings = (database.table('sensor_readings').select('*').eq('zone_id', zone_id)
                .order('created_at', desc=True).order('id', desc=True).limit(1).execute().data)
    result = {'zone_id': zone_id, 'reading': readings[0] if readings else None,
              'crop': None, 'fertilizer': None, 'status': 'insufficient_evidence',
              'fertilizer_crop': zones[0].get('current_crop'), 'fertilizer_crop_source': 'planted',
              'crop_error': None, 'fertilizer_error': None}
    if not readings:
        return result
    reading = readings[0]
    try:
        sampled_at = datetime.fromisoformat(reading['created_at'].replace('Z', '+00:00'))
        if sampled_at.tzinfo is None:
            raise ValueError()
    except (KeyError, ValueError, TypeError, AttributeError):
        result['crop_error'] = result['fertilizer_error'] = 'Source measurement time is invalid.'
        return result
    now = now or datetime.now(timezone.utc)
    if now - sampled_at > MAX_READING_AGE or sampled_at > now + timedelta(minutes=1):
        result['status'] = 'stale'
        result['crop_error'] = result['fertilizer_error'] = 'Collect a fresh measurement before requesting advice.'
        return result
    values = {}
    for field in FIELDS:
        raw = reading.get(field)
        try:
            value = float(raw)
        except (TypeError, ValueError):
            result['status'] = 'incomplete'
            result['crop_error'] = result['fertilizer_error'] = f'Latest reading is missing a valid {field}; no recommendation can be established.'
            return result
        if isinstance(raw, bool) or not math.isfinite(value):
            result['status'] = 'incomplete'
            result['crop_error'] = result['fertilizer_error'] = f'Latest reading is missing a valid {field}; no recommendation can be established.'
            return result
        if (field in ('soil_moisture', 'humidity') and not 0 <= value <= 100
            or field == 'ph' and not 0 <= value <= 14
            or field in ('nitrogen', 'phosphorus', 'potassium') and value < 0
            or field in ('soil_temperature', 'air_temperature') and not -50 <= value <= 80):
            result['status'] = 'invalid'
            result['crop_error'] = result['fertilizer_error'] = f'Latest reading has invalid {field}; inspect the sensor.'
            return result
        values[field] = value
    if reading.get('source') != 'device' or not reading.get('calibration_id'):
        result['crop_error'] = result['fertilizer_error'] = 'Verified sensor calibration and measurement provenance are required.'
        return result
    try:
        result['crop'] = crop_model(values)
    except ValueError as exc:
        result['crop_error'] = str(exc)
    planted = zones[0].get('current_crop')
    if not planted:
        result['fertilizer_error'] = 'Record the planted crop before evaluating fertilizer.'
    else:
        try:
            result['fertilizer'] = fertilizer_model(values, normalize_crop(planted))
        except ValueError as exc:
            result['fertilizer_error'] = str(exc)
    if result['crop'] or result['fertilizer']:
        result['status'] = 'model_options'
    return result
