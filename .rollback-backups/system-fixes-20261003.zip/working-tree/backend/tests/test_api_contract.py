import os
import sys
import unittest
from types import SimpleNamespace, ModuleType
from unittest.mock import Mock, patch
from uuid import uuid4
from datetime import datetime, timezone
from fastapi.testclient import TestClient

# Import the application without loading credentials or contacting a real database.
stub = ModuleType('app.database.supabase')
stub.supabase = Mock()
with patch.dict(sys.modules, {'app.database.supabase': stub}):
    from app import main
    from app.services import auth
from tests.test_zone_recommendations import Database
guidance_requests = main.guidance.__globals__['requests']

class ApiContractTest(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {'DEFAULT_FARM_ID': '7'})
        self.env.start()
        self.db = Database({'zones': [{'id': 1, 'farm_id': 7, 'current_crop': 'rice', 'soil_type': 'Loam', 'planted_on': None}],
                            'farm_memberships': [{'farm_id': 7, 'user_id': 'member'}]})
        self.db.auth = SimpleNamespace(get_user=Mock(return_value=SimpleNamespace(user=SimpleNamespace(id='member'))))
        self.db.rpc = Mock(return_value=SimpleNamespace(execute=lambda: SimpleNamespace(data={'id': 8})))
        self.main_patch = patch.object(main, 'supabase', self.db)
        self.auth_patch = patch.object(auth, 'supabase', self.db)
        self.main_patch.start()
        self.auth_patch.start()
        self.client = TestClient(main.app)
        self.headers = {'Authorization': 'Bearer session'}
        self.sample = {'device_id': str(uuid4()), 'sample_id': str(uuid4()), 'zone_id': 1,
                       'sampled_at': datetime.now(timezone.utc).isoformat(),
                       'soil_moisture': 35.5, 'soil_temperature': 24, 'air_temperature': 27,
                       'humidity': 70, 'ph': 6.4, 'nitrogen': 12.5, 'phosphorus': 19, 'potassium': 21}
        guidance_requests.clear()

    def tearDown(self):
        self.client.close()
        self.main_patch.stop()
        self.auth_patch.stop()
        self.env.stop()

    def test_anonymous_cannot_access_farm_data(self):
        for path in ['/zones', '/sensor?zone_id=1', '/zones/1/recommendations', '/devices']:
            self.assertEqual(self.client.get(path).status_code, 401)

    def test_invalid_session_rejected(self):
        self.db.auth.get_user.side_effect = ValueError('invalid')
        self.assertEqual(self.client.get('/zones', headers=self.headers).status_code, 401)

    def test_valid_session_requires_membership(self):
        self.db.rows['farm_memberships'] = []
        self.assertEqual(self.client.get('/zones', headers=self.headers).status_code, 403)

    def test_member_can_read_only_configured_farm_zones(self):
        self.db.rows['zones'].append({'id': 2, 'farm_id': 8})
        response = self.client.get('/zones', headers=self.headers)
        self.assertEqual(response.status_code, 200)
        self.assertEqual([zone['id'] for zone in response.json()['data']], [1])

    def test_cross_farm_zone_rejected(self):
        self.db.rows['zones'].append({'id': 2, 'farm_id': 8})
        self.assertEqual(self.client.get('/sensor?zone_id=2', headers=self.headers).status_code, 404)

    def test_device_token_required(self):
        self.assertEqual(self.client.post('/sensor', json=self.sample).status_code, 401)
        self.db.rpc.assert_not_called()

    def test_sample_has_identity_zone_time_and_fractional_nutrients(self):
        response = self.client.post('/sensor', json=self.sample, headers={'X-Device-Token': 'private-device-token'})
        self.assertEqual(response.status_code, 201)
        args = self.db.rpc.call_args.args
        self.assertEqual(args[0], 'ingest_device_reading')
        self.assertEqual(args[1]['payload']['nitrogen'], 12.5)
        self.assertNotIn('private-device-token', str(args))

    def test_invalid_sensor_measurements_rejected_before_database(self):
        for key, value in [('ph', 15), ('humidity', 101), ('soil_moisture', -1), ('nitrogen', True),
                           ('nitrogen', -1), ('zone_id', True), ('sampled_at', '2030-01-01T00:00:00Z')]:
            response = self.client.post('/sensor', json={**self.sample, key: value}, headers={'X-Device-Token': 'token'})
            self.assertEqual(response.status_code, 422, key)
        self.db.rpc.assert_not_called()

    def test_database_failure_cannot_report_saved(self):
        self.db.rpc.side_effect = ValueError('assignment mismatch')
        self.assertNotEqual(self.client.post('/sensor', json=self.sample, headers={'X-Device-Token': 'token'}).status_code, 201)

    def test_legacy_prediction_is_disabled(self):
        self.assertEqual(self.client.post('/predict', headers=self.headers).status_code, 410)

    def test_guidance_cannot_read_another_farm(self):
        self.assertEqual(self.client.post('/api/groq', headers=self.headers, json={'zone_id': 999}).status_code, 404)

    def test_guidance_needs_planted_crop(self):
        self.db.rows['zones'][0]['current_crop'] = None
        self.assertEqual(self.client.post('/api/groq', headers=self.headers, json={'zone_id': 1}).status_code, 422)

    def test_guidance_is_rate_limited_even_if_provider_unavailable(self):
        with patch.dict(os.environ, {'GROQ_API_KEY': ''}):
            for _ in range(10):
                self.assertEqual(self.client.post('/api/groq', headers=self.headers, json={'zone_id': 1}).status_code, 503)
            self.assertEqual(self.client.post('/api/groq', headers=self.headers, json={'zone_id': 1}).status_code, 429)

    def test_viewing_preference_never_reassigns_hardware(self):
        preferences = Mock()
        original = self.db.table
        with patch.object(self.db, 'table', side_effect=lambda name: preferences if name == 'farm_user_preferences' else original(name)) as tables:
            response = self.client.post('/device/active-zone', headers=self.headers, json={'zone_id': 1})
            self.assertEqual(response.status_code, 200)
            self.assertFalse(response.json()['device_assignment_changed'])
            self.assertNotIn('sensor_devices', [call.args[0] for call in tables.call_args_list])
            self.assertEqual(preferences.upsert.call_args.args[0]['user_id'], 'member')

    def test_viewing_preference_rejects_foreign_zone(self):
        self.assertEqual(self.client.post('/device/active-zone', headers=self.headers, json={'zone_id': 999}).status_code, 404)

    def test_soil_sensor_does_not_need_invented_air_measurements(self):
        sample = {key: value for key, value in self.sample.items() if key not in ('air_temperature', 'humidity')}
        response = self.client.post('/sensor', json=sample, headers={'X-Device-Token': 'token'})
        self.assertEqual(response.status_code, 201)
        self.assertIsNone(self.db.rpc.call_args.args[1]['payload']['air_temperature'])
        self.assertIsNone(self.db.rpc.call_args.args[1]['payload']['humidity'])
