import unittest
from unittest.mock import patch
from tempfile import TemporaryDirectory
from pathlib import Path
from app.services import model_policy
from app.machine_learning.predict import predict_crop
from app.machine_learning.predict_fertilizer import predict_fertilizer

class ModelPolicyTest(unittest.TestCase):
    def test_missing_validation_withholds_predictions_before_loading_artifacts(self):
        with TemporaryDirectory() as directory, patch.object(model_policy, 'MODEL_DIR', Path(directory)):
            with self.assertRaisesRegex(ValueError, 'validation'):
                predict_crop({})
            with self.assertRaisesRegex(ValueError, 'validation'):
                predict_fertilizer({}, 'rice')

    def test_crop_alias_matches_training_vocabulary(self):
        self.assertEqual(model_policy.normalize_crop(' Corn '), 'maize')
        self.assertEqual(model_policy.normalize_crop('rice'), 'rice')

    def test_unreviewed_metadata_is_rejected(self):
        import json
        with TemporaryDirectory() as directory, patch.object(model_policy, 'MODEL_DIR', Path(directory)):
            Path(directory, 'crop_metadata.json').write_text(json.dumps({'approved_for_field_use': False}))
            with self.assertRaisesRegex(ValueError, 'validation'):
                model_policy.approved_metadata('crop', model_policy.CROP_FEATURES)

    def test_stale_artifact_hash_is_rejected(self):
        import json
        with TemporaryDirectory() as directory, patch.object(model_policy, 'MODEL_DIR', Path(directory)):
            Path(directory, 'crop_model.pkl').write_bytes(b'changed-artifact')
            Path(directory, 'crop_metadata.json').write_text(json.dumps({
                'approved_for_field_use': True, 'features': model_policy.CROP_FEATURES,
                'validation_report': 'review', 'measurement_protocol': 'protocol',
                'model_version': 'v1', 'artifact_sha256': 'different-hash',
            }))
            with self.assertRaisesRegex(ValueError, 'artifact'):
                model_policy.approved_metadata('crop', model_policy.CROP_FEATURES)

    def test_legacy_rows_cannot_be_used_as_field_training(self):
        from app.machine_learning.train_model import train_model
        with TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, 'field observations'):
                train_model([{'crop': 'rice', 'soil_moisture': 75}], directory)
