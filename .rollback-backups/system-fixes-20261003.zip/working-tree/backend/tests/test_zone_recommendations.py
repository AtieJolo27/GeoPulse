from datetime import datetime, timezone
import unittest
from types import SimpleNamespace
from unittest.mock import Mock
from app.services.zone_recommendations import recommend_for_zone, FIELDS


class Database:
    def __init__(self, rows):
        self.rows = rows

    def table(self, name):
        return Query(self.rows[name])


class Query:
    def __init__(self, rows):
        self.rows = list(rows)
        self.orders = []

    def select(self, _):
        return self

    def eq(self, field, value):
        self.rows = [row for row in self.rows if row.get(field) == value]
        return self

    def order(self, field, desc=False):
        self.orders.append((field, desc))
        return self

    def limit(self, count):
        for field, desc in reversed(self.orders):
            self.rows.sort(key=lambda row: row[field], reverse=desc)
        self.rows = self.rows[:count]
        return self

    def execute(self):
        return SimpleNamespace(data=self.rows)


class ZoneRecommendationsTest(unittest.TestCase):
    def setUp(self):
        self.zone = {'id': 1, 'farm_id': 7, 'current_crop': 'rice'}
        self.reading = {**dict.fromkeys(FIELDS, 5), 'id': 1, 'zone_id': 1, 'created_at': '2026-10-03T00:00:00+00:00', 'source': 'device', 'calibration_id': 'verified'}
        self.crop = Mock(return_value={'best_crop': 'corn', 'recommendations': []})
        self.fertilizer = Mock(return_value={'recommendations': []})

    def run_prediction(self, readings):
        return recommend_for_zone(Database({'zones': [self.zone], 'sensor_readings': readings}), 1, 7, self.crop, self.fertilizer, now=datetime(2026, 10, 3, tzinfo=timezone.utc))

    def test_latest_in_selected_zone_and_planted_crop(self):
        result = self.run_prediction([self.reading, {**self.reading, 'id': 2, 'nitrogen': 12}, {**self.reading, 'zone_id': 2, 'id': 3}])
        self.assertEqual(result['reading']['id'], 2)
        self.assertEqual(self.crop.call_args.args[0]['nitrogen'], 12)
        self.assertEqual(self.fertilizer.call_args.args[1], 'rice')

    def test_missing_zone_readings_never_fall_back(self):
        result = self.run_prediction([{**self.reading, 'zone_id': 2}])
        self.assertIsNone(result['reading'])
        self.crop.assert_not_called()

    def test_incomplete_latest_does_not_use_old_reading(self):
        result = self.run_prediction([self.reading, {**self.reading, 'id': 2, 'ph': None}])
        self.assertEqual(result['status'], 'incomplete')
        self.assertEqual(result['reading']['id'], 2)
        self.assertIsNone(result['crop'])
        self.crop.assert_not_called()

    def test_no_planted_crop_withholds_fertilizer(self):
        self.zone['current_crop'] = None
        result = self.run_prediction([self.reading])
        self.assertIsNone(result['fertilizer'])
        self.fertilizer.assert_not_called()

    def test_unsupported_planted_crop_keeps_crop_result(self):
        self.fertilizer.side_effect = ValueError('unknown label')
        result = self.run_prediction([self.reading])
        self.assertIsNotNone(result['crop'])
        self.assertIsNone(result['fertilizer'])
        self.assertTrue(result['fertilizer_error'])

    def test_other_farm_cannot_be_requested(self):
        self.zone['farm_id'] = 8
        with self.assertRaises(ValueError):
            self.run_prediction([self.reading])

    def test_stale_reading_withholds_models(self):
        result = self.run_prediction([{**self.reading, 'created_at': '2020-01-01T00:00:00Z'}])
        self.assertEqual(result['status'], 'stale')
        self.crop.assert_not_called()
        self.fertilizer.assert_not_called()

    def test_uncalibrated_reading_withholds_models(self):
        result = self.run_prediction([{**self.reading, 'calibration_id': None}])
        self.assertIsNone(result['crop'])
        self.crop.assert_not_called()
        self.fertilizer.assert_not_called()

    def test_model_unavailability_does_not_hide_measurements(self):
        self.crop.side_effect = ValueError('Validation required')
        self.fertilizer.side_effect = ValueError('Validation required')
        result = self.run_prediction([self.reading])
        self.assertEqual(result['reading']['id'], 1)
        self.assertIsNone(result['crop'])
        self.assertIsNone(result['fertilizer'])

    def test_corn_alias(self):
        self.zone['current_crop'] = 'corn'
        self.run_prediction([self.reading])
        self.assertEqual(self.fertilizer.call_args.args[1], 'maize')

    def test_simulated_provenance_cannot_reach_models(self):
        self.run_prediction([{**self.reading, 'source': 'simulation'}])
        self.crop.assert_not_called()
        self.fertilizer.assert_not_called()

    def test_future_time_withholds_models(self):
        self.run_prediction([{**self.reading, 'created_at': '2030-01-01T00:00:00Z'}])
        self.crop.assert_not_called()



if __name__ == '__main__':
    unittest.main()
