import { useApp } from '@/shared/lib/AppContext';
import { useThemeColors } from '@/shared/lib/useThemeColors';
import { authenticatedFetch } from '@/lib/authenticatedFetch';
import { getApiUrl } from '@/lib/apiConfig';
import { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';

type Device = { id: string; name: string; zone_id: number | null; enabled: boolean };
export default function DeviceAssignments() {
  const { user, activeZoneId } = useApp();
  return <Assignments key={`${user?.id}:${activeZoneId}`} />;
}
function Assignments() {
  const { zones, activeZoneId, t, fontScale } = useApp();
  const colors = useThemeColors();
  const [devices, setDevices] = useState<Device[]>([]);
  const [name, setName] = useState('');
  const [credential, setCredential] = useState<{ id: string; token: string } | null>(null);
  const [busy, setBusy] = useState(true);
  const [message, setMessage] = useState('');
  const zone = zones.find(item => item.id === activeZoneId);
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    void (async () => {
      try {
        const response = await authenticatedFetch(getApiUrl('/devices'), { signal: controller.signal });
        if (!response.ok) throw new Error('Unable to load your farm sensors.');
        const json = await response.json();
        if (active) setDevices(json.data ?? []);
      } catch (error) { if (active) setMessage(error instanceof Error ? error.message : 'Unable to load sensors.'); }
      finally { if (active) setBusy(false); }
    })();
    return () => { active = false; controller.abort(); };
  }, []);
  async function register() {
    setBusy(true); setMessage('');
    try {
      const response = await authenticatedFetch(getApiUrl('/devices'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: name.trim() }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.detail ?? 'Unable to register sensor.');
      setCredential({ id: json.device_id, token: json.device_token });
      setDevices(previous => [...previous, { id: json.device_id, name: name.trim(), zone_id: null, enabled: true }]);
      setName('');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Unable to register sensor.'); }
    finally { setBusy(false); }
  }
  async function assign(device: Device) {
    if (activeZoneId === null) return;
    setBusy(true); setMessage('');
    try {
      const response = await authenticatedFetch(getApiUrl(`/devices/${device.id}/zone`), {
        method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ zone_id: activeZoneId }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.detail ?? 'Unable to assign sensor.');
      setDevices(previous => previous.map(row => row.id === device.id ? { ...row, zone_id: activeZoneId } : row));
      setMessage(t('Sensor assignment saved. New samples must identify this zone.', 'Na-save ang sona ng sensor. Dapat tukuyin ng bagong sukat ang sonang ito.'));
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Unable to assign sensor.'); }
    finally { setBusy(false); }
  }
  return <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={{ padding: 20 }}>
    <Text style={{ color: colors.text, fontWeight: '700', fontSize: 18 * fontScale }}>{t('Sensor field assignment', 'Sona ng sensor')}</Text>
    <Text style={{ color: colors.subText, marginVertical: 12 }}>{t('Viewing a zone does not move a sensor. Assign it only after placing it in the selected field.', 'Hindi inililipat ang sensor kapag pumipili ng sona. Itakda lamang ito pagkatapos ilagay sa napiling bukid.')}</Text>
    <Text style={{ color: colors.text, marginBottom: 12 }}>{t('Selected zone', 'Napiling sona')}: {zone ? t(zone.name_en, zone.name_tl) : t('None selected', 'Walang napili')}</Text>
    {busy && <ActivityIndicator color={colors.primary} />}
    {message !== '' && <Text accessibilityRole="alert" style={{ color: colors.subText, marginVertical: 12 }}>{message}</Text>}
    {devices.map(device => <View key={device.id} style={{ padding: 16, marginBottom: 12, borderRadius: 14, backgroundColor: colors.cardBg }}>
      <Text style={{ color: colors.text, fontWeight: '700' }}>{device.name}</Text>
      <Text style={{ color: colors.subText, marginVertical: 8 }}>{zones.find(item => item.id === device.zone_id)?.name_en ?? t('Unassigned', 'Walang sona')}</Text>
      <TouchableOpacity disabled={busy || !zone || !device.enabled || device.zone_id === activeZoneId} onPress={() => { void assign(device); }} accessibilityRole="button" style={{ minHeight: 44, justifyContent: 'center', opacity: busy || !zone || !device.enabled || device.zone_id === activeZoneId ? 0.5 : 1 }}>
        <Text style={{ color: colors.greenText }}>{t('Assign to selected zone', 'Itakda sa napiling sona')}</Text>
      </TouchableOpacity>
    </View>)}
    {credential ? <View style={{ padding: 16, backgroundColor: colors.cardBg, borderRadius: 14 }}>
      <Text style={{ color: colors.text }}>{t('Save this setup credential on the sensor. It is shown only once; keep it private.', 'I-save ang credential sa sensor. Isang beses lamang ito ipinapakita; panatilihing pribado.')}</Text>
      <Text selectable style={{ color: colors.subText, marginTop: 12 }}>Device ID: {credential.id}</Text>
      <Text selectable style={{ color: colors.subText, marginTop: 12 }}>Device token: {credential.token}</Text>
      <TouchableOpacity onPress={() => setCredential(null)} style={{ minHeight: 44, justifyContent: 'center' }} accessibilityRole="button"><Text style={{ color: colors.greenText }}>{t('I saved the credential', 'Na-save ko na ang credential')}</Text></TouchableOpacity>
    </View> : <View style={{ padding: 16, backgroundColor: colors.cardBg, borderRadius: 14 }}>
      <TextInput value={name} onChangeText={setName} maxLength={100} placeholder={t('New sensor name', 'Pangalan ng bagong sensor')} placeholderTextColor={colors.mutedText} style={{ color: colors.text, minHeight: 44 }} />
      <TouchableOpacity disabled={busy || !name.trim()} onPress={() => { void register(); }} style={{ minHeight: 44, justifyContent: 'center' }} accessibilityRole="button"><Text style={{ color: colors.greenText }}>{t('Register sensor', 'Irehistro ang sensor')}</Text></TouchableOpacity>
    </View>}
  </ScrollView>;
}
