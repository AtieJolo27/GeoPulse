import { useApp } from '@/shared/lib/AppContext';
import { useThemeColors } from '@/shared/lib/useThemeColors';
import { parseSensorNumber } from '@/lib/soilHealthScore';
import { Text, View } from 'react-native';
export type NutrientReading = {
  nitrogen?: number | string | null;
  phosphorus?: number | string | null;
  potassium?: number | string | null;
};
export default function NutrientPpmSummary({ reading }: { reading: NutrientReading }) {
  const { t, fontScale } = useApp();
  const colors = useThemeColors();
  return <View style={{ padding: 16, marginBottom: 16, borderRadius: 16, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg }}>
    <Text style={{ color: colors.text, fontSize: 16 * fontScale, fontWeight: '700', marginBottom: 12 }}>{t('Reported soil nutrients', 'Naitalang nutrient sa lupa')}</Text>
    {(['nitrogen', 'phosphorus', 'potassium'] as const).map(key => {
      const value = parseSensorNumber(reading[key]);
      return <Text key={key} style={{ color: colors.subText, fontSize: 14 * fontScale, marginBottom: 8 }}>{key.toUpperCase()}: {value !== null && value >= 0 ? `${value.toLocaleString(undefined, { maximumFractionDigits: 2 })} ppm` : t('Unavailable', 'Walang datos')}</Text>;
    })}
    <Text style={{ color: colors.subText, fontSize: 12 * fontScale, lineHeight: 18 * fontScale }}>{t('Required PPM and fertilizer amount are unavailable until a soil test establishes crop-specific nutrient need. Confirm sensor units and calibration; soil ppm is not the fertilizer concentration to mix into water.', 'Walang target na PPM o dami ng pataba hangga?t walang soil test para sa pangangailangan ng pananim. Kumpirmahin ang unit at calibration; ang ppm sa lupa ay hindi konsentrasyon ng pataba sa tubig.')}</Text>
  </View>;
}
