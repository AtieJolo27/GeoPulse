import { useApp } from '@/shared/lib/AppContext';
import { useThemeColors } from '@/shared/lib/useThemeColors';
import { readingIsFresh } from '@/lib/readingQuality';
import { supabase } from '@/lib/supabaseClient';
import { useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, Text, View, Pressable } from 'react-native';
import * as Linking from 'expo-linking';
import NutrientPpmSummary, { type NutrientReading } from './NutrientPpmSummary';

export default function RecommendationAssessment({ kind }: { kind: 'crop' | 'fertilizer' }) {
  const { t, fontScale, user } = useApp();
  const colors = useThemeColors();
  const params = useLocalSearchParams<{ crop?: string; fertilizer?: string; zoneId?: string; readingId?: string }>();
  const [state, setState] = useState<{ key: string; reading?: NutrientReading & { created_at: string }; crop?: string | null; error?: string } | null>(null);
  const [now, setNow] = useState(Date.now);
  const key = JSON.stringify([user?.id, params.zoneId, params.readingId]);
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    const timer = setInterval(() => setNow(Date.now()), 60_000);
    void (async () => {
      try {
        if (!params.zoneId || !params.readingId) throw new Error('Open a recommendation from a zone to view its source measurements.');
        const [reading, zone] = await Promise.all([
          supabase.from('sensor_readings').select('created_at,nitrogen,phosphorus,potassium').eq('zone_id', params.zoneId).eq('id', params.readingId).abortSignal(controller.signal).single(),
          supabase.from('zones').select('current_crop').eq('id', params.zoneId).abortSignal(controller.signal).single(),
        ]);
        if (reading.error || zone.error) throw new Error('Unable to load the source measurement or planted crop.');
        if (active) setState({ key, reading: reading.data, crop: zone.data.current_crop });
      } catch (error) { if (active) setState({ key, error: error instanceof Error ? error.message : 'Unable to load measurements.' }); }
    })();
    return () => { active = false; controller.abort(); clearInterval(timer); };
  }, [key, params.zoneId, params.readingId]);
  const current = state?.key === key ? state : null;
  return <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={{ padding: 24, paddingBottom: 110 }}>
    <Text style={{ color: colors.text, fontSize: 24 * fontScale, fontWeight: '700', marginBottom: 20 }}>{params[kind]?.replace(/_/g, ' ') ?? t('Option details', 'Detalye ng opsyon')}</Text>
    {!current ? <ActivityIndicator color={colors.primary} /> : current.error ? <Text accessibilityRole="alert" style={{ color: colors.warning }}>{current.error}</Text> : <>
      <Text style={{ color: colors.subText, marginBottom: 12 }}>{t('Planted crop', 'Itinanim na pananim')}: {current.crop?.replace(/_/g, ' ') ?? t('Not recorded', 'Hindi naitala')}</Text>
      {current.reading && <NutrientPpmSummary reading={current.reading} />}
      <View style={{ backgroundColor: colors.cardBg, padding: 16, borderRadius: 16 }}>
        <Text style={{ color: colors.subText, fontSize: 14 * fontScale, lineHeight: 22 * fontScale }}>{current.reading && !readingIsFresh(current.reading.created_at, now) ? t('These measurements are old. Collect a fresh reading before evaluating field actions.', 'Luma na ang mga sukat. Kumuha ng bagong datos bago suriin ang gagawin sa bukid.') : t('A model ranking does not establish field suitability, nutrient need or an application dose. Check crop-specific soil-test guidance with your agricultural technician. This page displays source measurements; it does not infer why the model chose this option.', 'Hindi pinatutunayan ng ranggo ng modelo ang kaangkupan, pangangailangan sa nutrient o dosis. Suriin ang soil test para sa pananim kasama ng agricultural technician. Mga pinagmulang sukat ang ipinapakita rito.')}</Text>
      </View>
      <Pressable onPress={() => { void Linking.openURL('https://nshp.bswm.da.gov.ph/fertmap/'); }} style={{ minHeight: 44, paddingVertical: 14 }} accessibilityRole="link"><Text style={{ color: colors.greenText }}>DA-BSWM FertMap</Text></Pressable>
    </>}
  </ScrollView>;
}
