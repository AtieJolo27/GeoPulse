import { supabase } from './supabaseClient';

export async function authenticatedFetch(url: string, options: RequestInit = {}) {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error || !session) throw new Error('Sign in to access your farm.');
  const headers = new Headers(options.headers);
  headers.set('Authorization', `Bearer ${session.access_token}`);
  return fetch(url, { ...options, headers });
}
