import { supabase } from '@/lib/supabaseClient';

export interface SoilHistoryRow {
  id: number;
  created_at: string;
  nitrogen: number | null;
  phosphorus: number | null;
  potassium: number | null;
  ph: number | null;
  air_temperature: number | null;
  soil_temperature: number | null;
  humidity: number | null;
  soil_moisture: number | null;
}

export async function getSoilHistory(zoneId: number, limit = 30): Promise<SoilHistoryRow[]> {
  const { data, error } = await supabase
    .from('sensor_readings')
    .select('id, created_at, nitrogen, phosphorus, potassium, ph, air_temperature, soil_temperature, humidity, soil_moisture')
    .eq('zone_id', zoneId)
    .order('created_at', { ascending: false })
    .order('id', { ascending: false })
    .limit(limit);

  if (error) {
    throw new Error('Unable to load this zone’s measurement history.');
  }
  return (data ?? []).reverse();
}
