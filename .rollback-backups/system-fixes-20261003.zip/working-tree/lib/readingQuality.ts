import { parseSensorNumber } from './soilHealthScore';

// Operational freshness limit, not an agronomic threshold.
export const MAX_READING_AGE_MS = 60 * 60 * 1000;
export function readingIsFresh(createdAt: unknown, now = Date.now()): boolean {
  if (typeof createdAt !== 'string') return false;
  const sampledAt = Date.parse(createdAt);
  return Number.isFinite(sampledAt) && sampledAt <= now + 60_000 && now - sampledAt <= MAX_READING_AGE_MS;
}
export function validMoisture(raw: unknown): number | null {
  const value = parseSensorNumber(raw);
  return value !== null && value >= 0 && value <= 100 ? value : null;
}
