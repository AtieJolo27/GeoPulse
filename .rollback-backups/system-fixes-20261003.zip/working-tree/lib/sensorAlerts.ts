import { parseSensorNumber } from './soilHealthScore';
import { readingIsFresh } from './readingQuality';
export interface SensorReading {
  id?: string | number;
  created_at?: string;
  [key: string]: unknown;
}
export interface SensorAlert {
  field: string; fieldTl: string; message: string; messageTl: string;
  date: string; dateTl: string; severity: 'high' | 'medium' | 'low';
}
export function computeSensorAlerts(record: SensorReading | null): SensorAlert[] {
  if (!record) return [];
  if (!readingIsFresh(record.created_at)) return [{
    field: 'Measurement freshness', fieldTl: 'Pagiging bago ng sukat',
    message: 'Fresh sensor measurements are needed before evaluating field actions.',
    messageTl: 'Kailangan ng bagong sukat bago suriin ang gagawin sa bukid.',
    date: record.created_at ?? 'Unknown sample time', dateTl: record.created_at ?? 'Walang oras',
    severity: 'medium',
  }];
  const bounds: Record<string, [number, number]> = { soil_moisture: [0, 100], humidity: [0, 100], ph: [0, 14], soil_temperature: [-50, 80], air_temperature: [-50, 80], nitrogen: [0, Infinity], phosphorus: [0, Infinity], potassium: [0, Infinity] };
  return Object.entries(bounds).flatMap(([key, [min, max]]) => {
    const value = parseSensorNumber(record[key]);
    if (value !== null && value >= min && value <= max) return [];
    return [{
      field: key.replace(/_/g, ' '), fieldTl: key.replace(/_/g, ' '),
      message: 'Measurement missing or invalid. Check the sensor before making decisions.',
      messageTl: 'Kulang o mali ang sukat. Suriin ang sensor bago magdesisyon.',
      date: record.created_at ?? '', dateTl: record.created_at ?? '', severity: 'medium' as const,
    }];
  });
}
