import { authenticatedFetch } from './authenticatedFetch';
export async function loadZoneRecommendations(baseUrl: string, zoneId: number, signal: AbortSignal) {
  const response = await authenticatedFetch(`${baseUrl.replace(/\/+$/, '')}/zones/${zoneId}/recommendations`, { signal });
  const json = await response.json();
  if (!response.ok) throw new Error(typeof json.detail === 'string' ? json.detail : 'Unable to load recommendations.');
  return json;
}
