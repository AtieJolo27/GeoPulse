import { Ionicons } from '@expo/vector-icons';
import { DrawerToggleButton } from 'expo-router/drawer';
import { useState } from 'react';
import { Modal, Text, TouchableOpacity, View } from 'react-native';
import { NotificationButton } from '@/shared/components/NotificationButton';
import SensorWifiScreen from '@/shared/components/SensorWifiScreen';
import { WeatherIndicator } from '@/shared/components/WeatherIndicator';
import DeviceAssignments from '@/components/DeviceAssignments';


export function HeaderActions() {
  const [wifiModalVisible, setWifiModalVisible] = useState(false);
  const [sensorTab, setSensorTab] = useState<'assignment' | 'wifi'>('assignment');

  return (
    <>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginRight: 2 }}>
        

        <WeatherIndicator />
        <TouchableOpacity
          accessibilityRole="button"
          accessibilityLabel="Sensor Wi-Fi"
          onPress={() => setWifiModalVisible(true)}
          hitSlop={8}
          activeOpacity={0.7}
          style={{ width: 36, height: 36, alignItems: 'center', justifyContent: 'center' }}
        >
          <Ionicons name="wifi" size={22} color="#FFFFFF" />
        </TouchableOpacity>
        <NotificationButton />
        <DrawerToggleButton
  tintColor="#FFFFFF"
/>
        {/* <TouchableOpacity accessibilityRole="button" accessibilityLabel="Open profile" onPress={() => router.push('/profile')} hitSlop={8} activeOpacity={0.7} style={{ width: 36, height: 36, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="person-circle-outline" size={25} color="#FFFFFF" />
        </TouchableOpacity> */}
      </View>

      <Modal
        visible={wifiModalVisible}
        animationType="slide"
        onRequestClose={() => setWifiModalVisible(false)}
      >
        <View style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: 20,
              paddingTop: 50,
              paddingBottom: 12,
              backgroundColor: '#1B5E37',
            }}
          >
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: 'white' }}>Sensor Wi-Fi</Text>
            <TouchableOpacity
              onPress={() => setWifiModalVisible(false)}
              accessibilityRole="button"
              accessibilityLabel="Close"
            >
              <Ionicons name="close-circle" size={28} color="white" />
            </TouchableOpacity>
          </View>

          <View style={{ flexDirection: 'row', padding: 12, gap: 16 }}>
            <TouchableOpacity onPress={() => setSensorTab('assignment')} style={{ minHeight: 44, justifyContent: 'center' }}><Text>Field assignment</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => setSensorTab('wifi')} style={{ minHeight: 44, justifyContent: 'center' }}><Text>Wi-Fi setup</Text></TouchableOpacity>
          </View>
          {sensorTab === 'assignment' ? <DeviceAssignments /> : <SensorWifiScreen />}
        </View>
      </Modal>
    </>
  );
}
