
export { getSoilHistory } from '@/lib/getHistory';
export type { SoilHistoryRow } from '@/lib/getHistory';
