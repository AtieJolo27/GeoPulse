-- Run the complete transaction. Existing tables and readings are preserved.
-- Only this migration's named policies/functions are replaced when rerun.
-- Unexpected existing types/constraints cause rollback; do not remove old tables.
BEGIN;

CREATE TABLE IF NOT EXISTS public.farm_memberships (
  farm_id bigint NOT NULL REFERENCES public.farms(id),
  user_id uuid NOT NULL REFERENCES auth.users(id),
  PRIMARY KEY (farm_id, user_id)
);
ALTER TABLE public.farm_memberships ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS membership_read ON public.farm_memberships;
CREATE POLICY membership_read ON public.farm_memberships FOR SELECT TO authenticated USING (user_id = auth.uid());
REVOKE ALL ON public.farm_memberships FROM anon, authenticated;
GRANT SELECT ON public.farm_memberships TO authenticated;
GRANT ALL ON public.farm_memberships TO service_role;

CREATE OR REPLACE FUNCTION public.has_farm_access(target_farm bigint) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  SELECT EXISTS (SELECT 1 FROM public.farm_memberships WHERE farm_id = target_farm AND user_id = auth.uid());
$$;
REVOKE ALL ON FUNCTION public.has_farm_access(bigint) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_farm_access(bigint) TO authenticated;

CREATE TABLE IF NOT EXISTS public.sensor_devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farm_id bigint NOT NULL REFERENCES public.farms(id),
  name text NOT NULL,
  zone_id bigint REFERENCES public.zones(id),
  token_hash text NOT NULL UNIQUE,
  enabled boolean NOT NULL DEFAULT true,
  calibration_id uuid
);
-- Preserve existing devices. Never invent farm assignments or credentials.
-- Missing identity columns require schema review rather than rewriting existing IDs.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'sensor_devices'
      AND column_name = 'id' AND data_type = 'uuid') THEN
    RAISE EXCEPTION 'Existing sensor_devices.id must be UUID. Migration stopped without committing; share the table schema before converting IDs.';
  END IF;
END;
$$;
ALTER TABLE public.sensor_devices ADD COLUMN IF NOT EXISTS farm_id bigint REFERENCES public.farms(id);
ALTER TABLE public.sensor_devices ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE public.sensor_devices ADD COLUMN IF NOT EXISTS zone_id bigint REFERENCES public.zones(id);
ALTER TABLE public.sensor_devices ADD COLUMN IF NOT EXISTS token_hash text;
-- Existing devices without an enabled column start disabled until provisioned.
ALTER TABLE public.sensor_devices ADD COLUMN IF NOT EXISTS enabled boolean NOT NULL DEFAULT false;
ALTER TABLE public.sensor_devices ALTER COLUMN enabled SET DEFAULT true;
ALTER TABLE public.sensor_devices ADD COLUMN IF NOT EXISTS calibration_id uuid;
ALTER TABLE public.sensor_devices ALTER COLUMN id SET DEFAULT gen_random_uuid();
CREATE UNIQUE INDEX IF NOT EXISTS sensor_device_token_hash_unique ON public.sensor_devices(token_hash);

CREATE TABLE IF NOT EXISTS public.sensor_calibrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id uuid NOT NULL REFERENCES public.sensor_devices(id),
  measurement_protocol jsonb NOT NULL,
  validation_report text NOT NULL,
  approved_by uuid NOT NULL REFERENCES auth.users(id),
  expires_at timestamptz NOT NULL,
  CHECK (measurement_protocol <> '{}'::jsonb),
  CHECK (length(validation_report) > 0)
);
DO $$
BEGIN
  -- Keep column creation with the constraint for existing device tables.
  ALTER TABLE public.sensor_devices ADD COLUMN IF NOT EXISTS calibration_id uuid;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.sensor_devices'::regclass AND conname = 'device_calibration_fk') THEN
    ALTER TABLE public.sensor_devices ADD CONSTRAINT device_calibration_fk
      FOREIGN KEY (calibration_id) REFERENCES public.sensor_calibrations(id);
  END IF;
END;
$$;

CREATE TABLE IF NOT EXISTS public.farm_user_preferences (
  farm_id bigint NOT NULL REFERENCES public.farms(id),
  user_id uuid NOT NULL REFERENCES auth.users(id),
  zone_id bigint REFERENCES public.zones(id),
  PRIMARY KEY (farm_id, user_id)
);
ALTER TABLE public.sensor_devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_calibrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farm_user_preferences ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.sensor_devices, public.sensor_calibrations, public.farm_user_preferences FROM anon, authenticated;
GRANT ALL ON public.sensor_devices, public.sensor_calibrations, public.farm_user_preferences TO service_role;

ALTER TABLE public.sensor_readings ADD COLUMN IF NOT EXISTS device_id uuid REFERENCES public.sensor_devices(id);
ALTER TABLE public.sensor_readings ADD COLUMN IF NOT EXISTS sample_id uuid;
ALTER TABLE public.sensor_readings ADD COLUMN IF NOT EXISTS calibration_id uuid REFERENCES public.sensor_calibrations(id);
ALTER TABLE public.sensor_readings ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'unverified';
ALTER TABLE public.sensor_readings ADD COLUMN IF NOT EXISTS received_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.sensor_readings ALTER COLUMN nitrogen TYPE double precision USING nitrogen::double precision;
ALTER TABLE public.sensor_readings ALTER COLUMN phosphorus TYPE double precision USING phosphorus::double precision;
ALTER TABLE public.sensor_readings ALTER COLUMN potassium TYPE double precision USING potassium::double precision;
CREATE UNIQUE INDEX IF NOT EXISTS sensor_sample_unique ON public.sensor_readings(device_id, sample_id) WHERE device_id IS NOT NULL AND sample_id IS NOT NULL;

ALTER TABLE public.zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_readings ENABLE ROW LEVEL SECURITY;
-- Restrictive gates also constrain pre-existing permissive policies.
DROP POLICY IF EXISTS zone_membership_gate ON public.zones;
CREATE POLICY zone_membership_gate ON public.zones AS RESTRICTIVE FOR ALL TO authenticated
  USING (public.has_farm_access(farm_id)) WITH CHECK (public.has_farm_access(farm_id));
DROP POLICY IF EXISTS zone_member_read ON public.zones;
CREATE POLICY zone_member_read ON public.zones FOR SELECT TO authenticated USING (public.has_farm_access(farm_id));
DROP POLICY IF EXISTS zone_member_update ON public.zones;
CREATE POLICY zone_member_update ON public.zones FOR UPDATE TO authenticated USING (public.has_farm_access(farm_id)) WITH CHECK (public.has_farm_access(farm_id));
DROP POLICY IF EXISTS reading_membership_gate ON public.sensor_readings;
CREATE POLICY reading_membership_gate ON public.sensor_readings AS RESTRICTIVE FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.zones z WHERE z.id = zone_id AND public.has_farm_access(z.farm_id)));
DROP POLICY IF EXISTS reading_member_read ON public.sensor_readings;
CREATE POLICY reading_member_read ON public.sensor_readings FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.zones z WHERE z.id = zone_id AND public.has_farm_access(z.farm_id)));
REVOKE ALL ON public.zones, public.sensor_readings FROM anon, authenticated;
GRANT SELECT ON public.zones, public.sensor_readings TO authenticated;
GRANT UPDATE (current_crop, planted_on, updated_at) ON public.zones TO authenticated;
GRANT ALL ON public.zones, public.sensor_readings TO service_role;
ALTER TABLE public.farms ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS farm_membership_gate ON public.farms;
CREATE POLICY farm_membership_gate ON public.farms AS RESTRICTIVE FOR SELECT TO authenticated
  USING (public.has_farm_access(id));
DROP POLICY IF EXISTS farm_member_read ON public.farms;
CREATE POLICY farm_member_read ON public.farms FOR SELECT TO authenticated USING (public.has_farm_access(id));
REVOKE ALL ON public.farms FROM anon, authenticated;
GRANT SELECT ON public.farms TO authenticated;

-- Legacy prediction data have no trustworthy zone lineage; only the server may access them.
ALTER TABLE public.crop_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fertilizer_predictions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.crop_predictions, public.fertilizer_predictions FROM anon, authenticated;

CREATE OR REPLACE FUNCTION public.ingest_device_reading(payload jsonb, credential_hash text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
  device public.sensor_devices;
  saved public.sensor_readings;
  verified_calibration uuid;
BEGIN
  SELECT * INTO device FROM public.sensor_devices WHERE id = (payload->>'device_id')::uuid FOR SHARE;
  IF device.id IS NULL OR device.enabled IS DISTINCT FROM true
     OR device.token_hash IS NULL OR credential_hash IS NULL
     OR device.token_hash <> credential_hash THEN
    RAISE EXCEPTION 'Invalid device credential';
  END IF;
  IF device.zone_id IS NULL OR device.zone_id <> (payload->>'zone_id')::bigint
     OR NOT EXISTS (SELECT 1 FROM public.zones WHERE id = device.zone_id AND farm_id = device.farm_id) THEN
    RAISE EXCEPTION 'Device assignment mismatch';
  END IF;
  IF (payload->>'sampled_at')::timestamptz > now() + interval '1 minute' THEN
    RAISE EXCEPTION 'Invalid sample time';
  END IF;
  SELECT id INTO verified_calibration FROM public.sensor_calibrations
    WHERE id = device.calibration_id AND device_id = device.id AND expires_at > now();
  -- Backend validation precedes this service-only RPC. Unknown calibration stays unknown.
  INSERT INTO public.sensor_readings (zone_id, device_id, sample_id, calibration_id, source,
    created_at, soil_moisture, soil_temperature, air_temperature, humidity, ph, nitrogen, phosphorus, potassium)
  VALUES (device.zone_id, device.id, (payload->>'sample_id')::uuid, verified_calibration, 'device',
    (payload->>'sampled_at')::timestamptz, (payload->>'soil_moisture')::double precision,
    (payload->>'soil_temperature')::double precision, (payload->>'air_temperature')::double precision,
    (payload->>'humidity')::double precision, (payload->>'ph')::double precision,
    (payload->>'nitrogen')::double precision, (payload->>'phosphorus')::double precision, (payload->>'potassium')::double precision)
  ON CONFLICT (device_id, sample_id) WHERE device_id IS NOT NULL AND sample_id IS NOT NULL DO NOTHING
  RETURNING * INTO saved;
  IF saved.id IS NULL THEN
    SELECT * INTO saved FROM public.sensor_readings WHERE device_id = device.id AND sample_id = (payload->>'sample_id')::uuid;
  END IF;
  RETURN to_jsonb(saved);
END;
$$;
REVOKE ALL ON FUNCTION public.ingest_device_reading(jsonb, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.ingest_device_reading(jsonb, text) TO service_role;
COMMIT;
