const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');
function endpoint(base = 'https://example.test') {
  const calls = [];
  const context = { exports: {}, Response, AbortSignal, process: { env: { EXPO_PUBLIC_API_URL: base } },
    fetch: async (...args) => { calls.push(args); return Response.json({ data: 'General crop care' }); },
  };
  vm.runInNewContext(ts.transpileModule(fs.readFileSync('app/api/groq+api.ts', 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText, context);
  return { post: token => context.exports.POST(new Request('http://localhost/api/groq', { method: 'POST', headers: token ? { Authorization: token } : {}, body: JSON.stringify({ zone_id: 7 }) })), calls };
}
test('unauthenticated guidance never reaches the backend', async () => {
  const api = endpoint();
  assert.equal((await api.post()).status, 401);
  assert.equal(api.calls.length, 0);
});
test('web proxy preserves session and authorized zone context', async () => {
  const api = endpoint();
  assert.equal((await api.post('Bearer test-session')).status, 200);
  assert.equal(api.calls[0][0], 'https://example.test/api/groq');
  assert.equal(api.calls[0][1].headers.Authorization, 'Bearer test-session');
  assert.equal(JSON.parse(api.calls[0][1].body).zone_id, 7);
});
test('missing production backend fails explicitly', async () => {
  const api = endpoint('');
  assert.equal((await api.post('Bearer test')).status, 503);
  assert.equal(api.calls.length, 0);
});
