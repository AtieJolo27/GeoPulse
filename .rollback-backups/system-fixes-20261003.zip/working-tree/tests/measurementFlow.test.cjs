const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');
function moduleFor(file, require) {
  const context = { exports: {}, require, Headers, fetch: async (...args) => args };
  vm.runInNewContext(ts.transpileModule(fs.readFileSync(file, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText, context);
  return context.exports;
}
const quality = moduleFor('lib/readingQuality.ts', () => ({ parseSensorNumber: value => {
  if (value == null || (typeof value !== 'number' && typeof value !== 'string') || value === '') return null;
  const n = Number(value); return Number.isFinite(n) ? n : null;
} }));
test('freshness rejects unknown, old, invalid and future sample times', () => {
  const now = Date.parse('2026-10-03T00:00:00Z');
  for (const raw of [null, undefined, 'invalid', '2020-01-01', '2026-10-04T00:00:00Z']) assert.equal(quality.readingIsFresh(raw, now), false);
  assert.equal(quality.readingIsFresh('2026-10-02T23:59:00Z', now), true);
});
test('moisture preserves valid zero and withholds invalid measurements', () => {
  assert.equal(quality.validMoisture(0), 0);
  for (const raw of [null, undefined, true, -1, 101, 'bad']) assert.equal(quality.validMoisture(raw), null);
});
test('history selects latest source measurements in one zone then displays chronologically', async () => {
  const calls = [];
  const query = { then: resolve => resolve({ data: [{ id: 2 }, { id: 1 }], error: null }) };
  for (const method of ['select', 'eq', 'order', 'limit']) query[method] = (...args) => { calls.push([method, ...args]); return query; };
  const history = moduleFor('lib/getHistory.ts', () => ({ supabase: { from: table => { calls.push(['from', table]); return query; } } }));
  assert.equal((await history.getSoilHistory(7))[0].id, 1);
  assert.equal(calls[0][1], 'sensor_readings');
  assert.equal(calls.find(row => row[0] === 'eq')[2], 7);
  assert.equal(calls.find(row => row[0] === 'order')[2].ascending, false);
});
test('authenticated API requests require a session', async () => {
  const auth = moduleFor('lib/authenticatedFetch.ts', () => ({ supabase: { auth: { getSession: async () => ({ data: { session: null }, error: null }) } } }));
  await assert.rejects(auth.authenticatedFetch('https://example.test'), /Sign in/);
});
