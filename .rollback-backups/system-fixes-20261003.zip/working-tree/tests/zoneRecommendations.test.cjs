const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');
const code = ts.transpileModule(fs.readFileSync('lib/zoneRecommendations.ts', 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText;
function setup(status = 200) {
  const requests = [];
  const context = { exports: {}, require: () => ({ authenticatedFetch: async (url, options) => {
    requests.push({ url, options });
    return { ok: status === 200, json: async () => status === 200 ? { zone_id: 7, reading: null, crop: null, fertilizer: null } : { detail: 'Service error' } };
  } }) };
  vm.runInNewContext(code, context);
  return { load: context.exports.loadZoneRecommendations, requests };
}
test('requests only the authenticated selected-zone endpoint', async () => {
  const { load, requests } = setup();
  assert.equal((await load('https://example.test/', 7, new AbortController().signal)).zone_id, 7);
  assert.equal(requests[0].url, 'https://example.test/zones/7/recommendations');
  assert.equal(requests.length, 1);
});
test('old servers cannot trigger unsafe prediction fallback', async () => {
  const { load, requests } = setup(404);
  await assert.rejects(load('https://example.test', 7, new AbortController().signal), /Service error/);
  assert.equal(requests.length, 1);
});
test('server failures do not fetch unscoped measurements', async () => {
  const { load, requests } = setup(500);
  await assert.rejects(load('https://example.test', 7, new AbortController().signal), /Service error/);
  assert.equal(requests.length, 1);
});
